# Chunki autoscroller

49 oddzielnych PNG RGB, każdy 1088 × 816 px. Białe tło, niebieski kontur 4 px, bez etykiet w teksturach. Wnętrze korytarza i obszar poza nim są białe, zgodnie ze szkicem. Kontur oznacza ściany; obszary ruchu opisuje JSON. Zachowano 40 poprzednich wariantów i dodano 9 chunków ze skrzyżowaniami, scaleniami i zakrętami.

## Łączenie

Kierunek gry: w prawo. Lewy górny róg to (0,0), Y rośnie w dół. Trzy środki portów: Upper=136, Middle=408, Lower=680. Wysokość korytarza: 128 px. Sąsiadujące chunki ustawiaj co 1088 px w X, bez odstępów, na tej samej wysokości Y. Pełny zestaw prawych portów musi odpowiadać pełnemu zestawowi lewych portów następnego chunka. GoingUp łączy Lower → Upper, GoingDown Upper → Lower. Krótsze przejścia łączą poziom środkowy z górnym lub dolnym. Góra i dół obrazka nie mają portów.

Start ma zamkniętą lewą ścianę, Finish zamkniętą prawą. SplitRoom rozdziela środkowy korytarz na dwa. DoubleStraight prowadzi dwa niezależne korytarze. KeepUpper zamyka dolny, KeepLower zamyka górny. DeadEnd i jego warianty zamykają pojedynczy korytarz.

## Jedna poprawna trasa

ExampleLevel.png zawiera 24 połączone chunki, 5 rozwidleń, 5 ślepych zakończeń i dokładnie jedną trasę do mety. BranchingPreview.png pokazuje ten sam poziom w sześciu kolejnych pasach po cztery chunki (kolejny pas jest kontynuacją poprzedniego, a nie pokojem poniżej). Pełna sekwencja jest w polu example w connections.json.

BranchUpper / BranchLower dodają boczną odnogę obok prostej trasy. TripleSplit ma trzy wyjścia. SplitUpperKeepLower / SplitLowerKeepUpper rozdzielają jedną z dwóch istniejących odnóg, zachowując drugą. BranchDownKeepUpper / BranchUpKeepLower umożliwiają dalsze rozgałęzienie dwóch sąsiednich korytarzy. TripleStraight przedłuża trzy niezależne odnogi. Chunki Close oraz TripleKeep zamykają wybrane korytarze bez scalania dróg. Sąsiednie korytarze mają 144 px odstępu między granicami obszarów ruchu: nie rozszerzaj ich polygonów, bo mogłyby się połączyć.

Jeśli wymagasz dokładnie jednej drogi do mety, generator powinien kończyć alternatywne odnogi przed ich ponownym scaleniem i sprawdzać liczbę skierowanych ścieżek Start→Finish. W JSON connected_port_groups opisuje połączenia WEWNĄTRZ chunka: nie traktuj DoubleStraight jako jednego wspólnego węzła. Wspólne skrzyżowania mogą tworzyć wiele poprawnych tras. Sam BFS znajduje osiągalność i trasę o najmniejszej liczbie krawędzi, nie dowodzi jej unikalności ani najmniejszej długości geometrycznej. Grywalność zależy też od wymiarów postaci, prędkości scrollowania i mechaniki ruchu.

## Skrzyżowania i wymuszone zakręty

CrossX łączy przekątne Upper→Lower oraz Lower→Upper we wspólnym środku. CrossUpperMiddle i CrossMiddleLower to wersje dla sąsiednich poziomów. CrossTriple łączy wszystkie trzy poziomy. Na przecięciu można zmienić odnogę: nie jest to most ani tunel z niezależnymi kolizjami. MergeRoom i jego warianty scalają dwie odnogi. ZigZagUp i ZigZagDown mają porty Middle→Middle, ale wymagają objazdu górą albo dołem, więc nie da się przejechać poziomo przez środek.

CrossingLevel.png pokazuje 16 chunków ze skrzyżowaniami i wymuszonymi zmianami wysokości; CrossingPreview.png dzieli go na cztery kolejne pasy. Ten przykład ma 8 skierowanych tras na poziomie portów, a nie jedną. Zamknięcia i przejścia GoingUp / GoingDown wymuszają zmianę wysokości na każdej z nich. Poprzedni ExampleLevel.png nadal pokazuje jedną trasę do mety. Aby wyznaczać najkrótszą trasę geometryczną, w generatorze potrzebny jest graf punktów wewnątrz korytarzy z wagami długości i algorytm Dijkstry lub A*; sam identyfikator chunka nie wystarczy.

## Dane i import

connections.json zawiera porty i sumę polygonów przejezdnego korytarza (walkable_polygons_union). Współrzędne X celowo wystają do -16 i 1104, aby raster nie zamykał portów; przy tworzeniu geometrii przytnij je do obszaru chunka. Białego tła nie używaj jako maski kolizji. Kolizje wymagają osobnej geometrii ścian.

W Godot ustaw pozycje bez ułamków, skalę 1:1 i wyłącz mipmapy, jeśli pojawią się szwy. Zaktualizowano zestaw Seamless i jego metadane; kod generatora Godot pozostaje bez zmian. Nowe porty nie pasują do starszych chunków 1088 × 544 — używaj całego nowego zestawu.

Preview.png, ExampleLevel.png, BranchingPreview.png, CrossingLevel.png i CrossingPreview.png są podglądami, a nie chunkami. Nowe grafiki i metadane nie zmieniają działającej sceny Godot: podłączenie zestawu wymaga użycia tych portów w generatorze.
